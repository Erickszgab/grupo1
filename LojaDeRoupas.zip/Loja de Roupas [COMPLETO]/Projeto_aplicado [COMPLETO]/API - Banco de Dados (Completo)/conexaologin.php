<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "luxshop";

// Conexão com banco
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica conexão
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Recebe dados do formulário
$email = $_POST['email'];
$senha = $_POST['senha'];

// Prepara a query segura (evita SQL injection)
$stmt = $conn->prepare("SELECT senha FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($senha_hash);
    $stmt->fetch();

    if (password_verify($senha, $senha_hash)) {
        echo "Login bem-sucedido!";
        // Redireciona ou inicia sessão
    } else {
        echo "Senha incorreta!";
    }
} else {
    echo "Usuário não encontrado.";
}

$stmt->close();
$conn->close();
?>