const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Conexão com o MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',        // coloca sua senha aqui
  database: 'loja'
});

// Verifica conexão
db.connect(err => {
  if (err) {
    console.error('Erro na conexão com o MySQL:', err);
    return;
  }
  console.log('🟢 Conectado ao MySQL!');
});

// Rota para listar todos os acessórios
app.get('/acessorios', (req, res) => {
  db.query('SELECT * FROM acessorios', (err, results) => {
    if (err) return res.status(500).json({ erro: 'Erro ao buscar acessórios' });
    res.json(results);
  });
});

// Rota para adicionar um acessório
app.post('/acessorios', (req, res) => {
  const { nome, preco, categoria, estoque } = req.body;
  const sql = 'INSERT INTO acessorios (nome, preco, categoria, estoque) VALUES (?, ?, ?, ?)';
  db.query(sql, [nome, preco, categoria, estoque || 0], (err, result) => {
    if (err) return res.status(500).json({ erro: 'Erro ao adicionar acessório' });
    res.status(201).json({ mensagem: 'Acessório adicionado com sucesso', id: result.insertId });
  });
});

// Iniciar servidor
app.listen(3001, () => {
  console.log('🚀 API rodando em http://localhost:3001');
});