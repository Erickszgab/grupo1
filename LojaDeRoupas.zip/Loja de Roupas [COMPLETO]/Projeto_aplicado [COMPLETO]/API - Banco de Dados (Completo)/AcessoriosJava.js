mkdir cadastro-api
cd cadastro-api
npm init -y
npm install express sqlite3 cors
mkdir public
touch server.js public/index.html