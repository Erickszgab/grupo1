const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');

const app = express();
const db = new sqlite3.Database('./cadastro.db');

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

db.run(`
  CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT UNIQUE,
    email TEXT UNIQUE,
    senha TEXT,
    telefone TEXT
  )
`);

app.post('/cadastro', (req, res) => {
  const {nome, email, senha, telefone } = req.body;
  if (!nome || !email || !senha || !telefone) {
    return res.status(400).json({ erro: 'Campos obrigatórios!' });
  }

  db.run(
    'INSERT INTO usuarios (nome, email, senha, telefone) VALUES (?, ?, ?, ?)',
    [nome, email, senha, telefone],
    function (err) {
      if (err) {
        return res.status(500).json({ erro: 'O Email já está cadastrado. Tente novamente!' });
      }
      res.status(201).json({ mensagem: "Você está cadastrado!", id: this.lastID });
    }
  );
});

app.listen(3000, () => {
  console.log('Hospedagem = http://localhost:3000');
});