const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');

const app = express();
const db = new sqlite3.Database('./carrinho.db');

app.use(cors());
app.use(express.json());

// Criar a tabela do carrinho
db.run(`
  CREATE TABLE IF NOT EXISTS carrinho (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT,
    preco REAL,
    quantidade INTEGER,
    imagem TEXT
  )
`);

// Listar o carrinho
app.get('/carrinho', (req, res) => {
  db.all('SELECT * FROM carrinho', (err, rows) => {
    if (err) return res.status(500).send(err);
    res.json(rows);
  });
});

// Adicionar produto ao carrinho
app.post('/carrinho', (req, res) => {
  const { nome, preco, quantidade, imagem } = req.body;
  db.run(
    'INSERT INTO carrinho (nome, preco, quantidade, imagem) VALUES (?, ?, ?, ?)',
    [nome, preco, quantidade, imagem],
    function (err) {
      if (err) return res.status(500).send(err);
      res.json({ id: this.lastID, nome, preco, quantidade, imagem });
    }
  );
});

// Remover item do carrinho
app.delete('/carrinho/:id', (req, res) => {
  db.run('DELETE FROM carrinho WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).send(err);
    res.json({ mensagem: 'Item removido com sucesso!' });
  });
});

// Esvaziar carrinho
app.delete('/carrinho', (req, res) => {
  db.run('DELETE FROM carrinho', [], function (err) {
    if (err) return res.status(500).send(err);
    res.json({ mensagem: 'Carrinho esvaziado com sucesso!' });
  });
});

app.listen(3001, () => {
  console.log('🛒 API do carrinho rodando em http://localhost:3001');
});
🧪 Testar
POST http://localhost:3001/carrinho
Corpo JSON:

json
Copiar
Editar
{
  "nome": "Camiseta Básica",
  "preco": 49.90,
  "quantidade": 2,
  "imagem": "https://linkdaimagem.com/camiseta.png"
}
GET http://localhost:3001/carrinho – Ver o que tem no carrinho

DELETE http://localhost:3001/carrinho/1 – Remove um item (id 1)

DELETE http://localhost:3001/carrinho – Limpa tudo

🤝 Como conectar ao HTML
No frontend (HTML + JS), você usa fetch pra mandar o produto pro carrinho:

js
Copiar
Editar
function adicionarAoCarrinho(produto) {
  fetch('http://localhost:3001/carrinho', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(produto)
  })
  .then(res => res.json())
  .then(data => {
    alert('Produto adicionado!');
    console.log(data);
  });
}

function adicionarAoCarrinho(produto) {
  fetch('http://localhost:3001/carrinho', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(produto)
  })
  .then(res => res.json())
  .then(data => {
    alert('Produto adicionado!');
    console.log(data);
  });
}